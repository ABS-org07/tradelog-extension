// TradeLog — Popup Script v2

let allTrades = [];
let currentFilter = 'today';
let isSampleMode = false;

// ── SAMPLE DATA ──
// 20 realistic Indian trades spread across last 7 days
function generateSampleTrades() {
  const now = Date.now();
  const day = 24 * 60 * 60 * 1000;
  const instruments = [
    { sym: 'RELIANCE', exchange: 'NSE', type: 'EQ' },
    { sym: 'NIFTY 24000 CE', exchange: 'NFO', type: 'OPT' },
    { sym: 'BANKNIFTY 51500 PE', exchange: 'NFO', type: 'OPT' },
    { sym: 'HDFC', exchange: 'NSE', type: 'EQ' },
    { sym: 'TCS', exchange: 'NSE', type: 'EQ' },
    { sym: 'INFY', exchange: 'NSE', type: 'EQ' },
    { sym: 'NIFTY 23900 PE', exchange: 'NFO', type: 'OPT' },
    { sym: 'SBIN', exchange: 'NSE', type: 'EQ' },
  ];
  const trades = [];
  const pnls = [820, -340, 1240, -180, 560, 980, -420, 1100, 440, -260,
                720, 1380, -190, 650, 880, -310, 540, 1020, -150, 760];
  let id = 1;
  for (let d = 6; d >= 0; d--) {
    const dayBase = now - d * day;
    const count = d === 0 ? 4 : (d % 2 === 0 ? 3 : 2);
    for (let t = 0; t < count; t++) {
      const inst = instruments[(id - 1) % instruments.length];
      const pnl  = pnls[(id - 1) % pnls.length];
      const buyPrice = inst.type === 'OPT' ? (80 + Math.random() * 120) : (500 + Math.random() * 2000);
      const qty      = inst.type === 'OPT' ? 50 : 10;
      const sellPrice = buyPrice + pnl / qty;
      trades.push({
        id: 'sample_' + id,
        symbol:    inst.sym,
        exchange:  inst.exchange,
        qty,
        buyPrice:  parseFloat(buyPrice.toFixed(2)),
        sellPrice: parseFloat(sellPrice.toFixed(2)),
        pnl,
        type:      'MIS',
        source:    'zerodha',
        emotion:   pnl > 0 ? 'disciplined' : (Math.random() > 0.5 ? 'fomo' : 'revenge'),
        timestamp: dayBase - (t * 90 * 60 * 1000) + 9 * 60 * 60 * 1000,
        isSample:  true,
      });
      id++;
    }
  }
  return trades;
}

document.addEventListener('DOMContentLoaded', () => {
  loadData();

  // When a real trade arrives while popup is open, exit sample mode
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.trades && isSampleMode) {
      const newTrades = changes.trades.newValue || [];
      if (newTrades.length > 0) {
        chrome.storage.local.set({ sampleDismissed: true });
        loadData(); // reload with real data
      }
    }
  });

  setupTabs();
  setupClearBtn();
  setupExportBtn();
  updateMarketStatus();
  setupChecklist();
  setupLossLimit();
  setupUpgradeBanner();
  setupLicenseKey();
});

function setupUpgradeBanner() {
  const banner = document.getElementById('upgrade-banner');
  const upgradeBtn = document.getElementById('upgrade-btn');
  const dismissBtn = document.getElementById('upgrade-dismiss');

  // Check if user is Pro or has dismissed the banner recently
  chrome.storage.local.get(['isPro', 'bannerDismissedAt'], (result) => {
    if (result.isPro) {
      banner.classList.add('hidden');
      return;
    }
    // Hide for 3 days after dismiss
    if (result.bannerDismissedAt) {
      const daysSince = (Date.now() - result.bannerDismissedAt) / (1000 * 60 * 60 * 24);
      if (daysSince < 3) {
        banner.classList.add('hidden');
        return;
      }
    }
  });

  upgradeBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://abs-org07.github.io/tradelog-extension/#pricing' });
  });

  dismissBtn.addEventListener('click', () => {
    banner.classList.add('hidden');
    chrome.storage.local.set({ bannerDismissedAt: Date.now() });
  });
}

function loadData() {
  chrome.storage.local.get(['trades', 'stats', 'sampleDismissed'], (result) => {
    const realTrades = result.trades || [];
    const stats = result.stats || {};

    if (realTrades.length === 0 && !result.sampleDismissed) {
      // Show sample mode
      isSampleMode = true;
      allTrades = generateSampleTrades();
      showSampleBanner();

      // Build fake stats from sample trades
      const sampleStats = buildSampleStats(allTrades);
      updateStatsStrip(sampleStats);
    } else {
      isSampleMode = false;
      allTrades = realTrades;
      hideSampleBanner();
      updateStatsStrip(stats);
    }

    updateSourceDots();
    renderChart();
    renderTrades(currentFilter);
    if (currentFilter === 'summary') renderSummary();
    if (currentFilter === 'debrief') renderDebrief();
  });
}

function buildSampleStats(trades) {
  const today = new Date().toDateString();
  const todayTrades = trades.filter(t => new Date(t.timestamp).toDateString() === today);
  const winners = trades.filter(t => t.pnl > 0);
  const todayPnL = todayTrades.reduce((s, t) => s + t.pnl, 0);
  const totalPnL = trades.reduce((s, t) => s + t.pnl, 0);
  return {
    todayPnL,
    todayTrades: todayTrades.length,
    winRate: trades.length ? Math.round((winners.length / trades.length) * 100) : 0,
    totalPnL,
  };
}

function showSampleBanner() {
  let banner = document.getElementById('sample-banner');
  if (!banner) {
    banner = document.createElement('div');
    banner.id = 'sample-banner';
    banner.innerHTML = `
      <span>📊 Sample Data · Place a real trade to start</span>
      <button id="sample-dismiss" title="Dismiss">✕</button>
    `;
    // Insert at top of popup body
    const body = document.querySelector('.popup-body') || document.body;
    body.insertBefore(banner, body.firstChild);

    document.getElementById('sample-dismiss').addEventListener('click', () => {
      chrome.storage.local.set({ sampleDismissed: true }, () => {
        isSampleMode = false;
        allTrades = [];
        hideSampleBanner();
        const stats = {};
        updateStatsStrip(stats);
        renderChart();
        renderTrades(currentFilter);
      });
    });
  }
  banner.style.display = 'flex';
}

function hideSampleBanner() {
  const banner = document.getElementById('sample-banner');
  if (banner) banner.style.display = 'none';
}

// ── STATS STRIP ──

function updateStatsStrip(stats) {
  const todayPnL = stats.todayPnL || 0;
  const pnlEl = document.getElementById('today-pnl');
  pnlEl.textContent = formatPnL(todayPnL);
  pnlEl.className = 'pnl-main-val ' + (todayPnL > 0 ? 'profit' : todayPnL < 0 ? 'loss' : '');

  document.getElementById('today-trades').textContent = stats.todayTrades || 0;
  document.getElementById('win-rate').textContent = (stats.winRate || 0) + '%';

  const totalPnL = stats.totalPnL || 0;
  const totalEl = document.getElementById('total-pnl');
  totalEl.textContent = formatPnL(totalPnL);
  totalEl.className = 'val ' + (totalPnL > 0 ? 'green' : totalPnL < 0 ? 'red' : 'white');

  const footerEl = document.getElementById('footer-text');
  if (isSampleMode) {
    footerEl.textContent = '📊 Sample data — place a real trade to begin';
  } else {
    footerEl.textContent = allTrades.length > 0
      ? `${allTrades.length} trade${allTrades.length !== 1 ? 's' : ''} logged`
      : 'Zero clicks needed';
  }
}

// ── 7-DAY CHART ──

function renderChart() {
  const container = document.getElementById('chart-bars');
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d);
  }

  const dayPnLs = days.map(d => {
    const dateStr = d.toDateString();
    const dayTrades = allTrades.filter(t =>
      new Date(t.timestamp).toDateString() === dateStr && t.pnl !== null
    );
    return dayTrades.reduce((sum, t) => sum + t.pnl, 0);
  });

  const maxAbs = Math.max(...dayPnLs.map(v => Math.abs(v)), 1);
  const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  container.innerHTML = days.map((d, i) => {
    const pnl = dayPnLs[i];
    const heightPct = Math.round((Math.abs(pnl) / maxAbs) * 100);
    const cls = pnl > 0 ? 'profit' : pnl < 0 ? 'loss' : 'zero';
    const dayLabel = `${d.getDate()}/${d.getMonth()+1}`;
    return `
      <div class="chart-bar-wrap" title="${pnl >= 0 ? '+' : ''}₹${pnl.toFixed(0)}">
        <div class="chart-bar ${cls}" style="height:${heightPct}%"></div>
        <div class="chart-day">${dayLabel}</div>
      </div>
    `;
  }).join('');
}

// ── RENDER TRADES ──

function renderTrades(filter) {
  const list = document.getElementById('trade-list');
  const emptyState = document.getElementById('empty-state');
  const summaryView = document.getElementById('summary-view');

  // Handle summary tab separately
  if (filter === 'summary') {
    list.style.display = 'none';
    summaryView.classList.add('active');
    renderSummary();
    return;
  }

  list.style.display = '';
  summaryView.classList.remove('active');

  const today = new Date().toDateString();
  let filtered;

  switch (filter) {
    case 'today':
      filtered = allTrades.filter(t => new Date(t.timestamp).toDateString() === today);
      break;
    case 'winners':
      filtered = allTrades.filter(t => t.pnl !== null && t.pnl > 0);
      break;
    case 'losers':
      filtered = allTrades.filter(t => t.pnl !== null && t.pnl < 0);
      break;
    default:
      filtered = allTrades;
  }

  if (filtered.length === 0) {
    emptyState.classList.add('show');
    list.innerHTML = '';
    list.appendChild(emptyState);
    return;
  }

  emptyState.classList.remove('show');

  list.innerHTML = filtered.map(trade => {
    const isBuy = trade.action === 'BUY';
    const productClass = 'product-' + (trade.product || 'mis').toLowerCase();
    const productLabel = trade.product || 'MIS';

    const pnlHtml = trade.pnl !== null
      ? `<div class="trade-pnl ${trade.pnl >= 0 ? 'green' : 'red'}">${formatPnL(trade.pnl)}</div>`
      : `<div class="trade-pnl" style="color:#3D4255">—</div>`;

    const sampleAttr = trade.isSample ? ' data-sample="1"' : '';
    const emotionDisabled = trade.isSample ? ' disabled' : '';
    const notesDisabled = trade.isSample ? ' disabled placeholder="Sample data"' : ' placeholder="Add note..."';

    return `
      <div class="trade-item${trade.isSample ? ' sample-trade' : ''}" data-id="${trade.id}"${sampleAttr}>
        <div class="action-badge ${isBuy ? 'action-buy' : 'action-sell'}">
          ${isBuy ? 'BUY' : 'SELL'}
        </div>
        <div class="trade-info">
          <div class="trade-symbol">
            ${escHtml(trade.symbol)}
            <span class="exchange-tag">${trade.exchange || 'NSE'}</span>
            <span class="product-tag ${productClass}">${productLabel}</span>
          </div>
          <div class="trade-detail">
            <span>${trade.qty || trade.quantity} qty</span> @ <span>₹${formatPrice(trade.buyPrice || trade.price)}</span>
            · <span style="color:#3D4255">${trade.source || 'zerodha'}</span>
          </div>
          <div class="trade-controls">
            <select class="emotion-select" data-id="${trade.id}" title="Tag emotion"${emotionDisabled}>
              <option value="">Tag emotion...</option>
              <option value="disciplined"   ${trade.emotion === 'disciplined'    ? 'selected' : ''}>✅ Disciplined</option>
              <option value="confident"     ${trade.emotion === 'confident'      ? 'selected' : ''}>💪 Confident</option>
              <option value="fomo"          ${trade.emotion === 'fomo'           ? 'selected' : ''}>😰 FOMO</option>
              <option value="revenge"       ${trade.emotion === 'revenge'        ? 'selected' : ''}>😤 Revenge</option>
              <option value="fearful"       ${trade.emotion === 'fearful'        ? 'selected' : ''}>😨 Fearful</option>
              <option value="overconfident" ${trade.emotion === 'overconfident'  ? 'selected' : ''}>🤑 Overconfident</option>
            </select>
            <input class="notes-input" type="text"${notesDisabled} data-id="${trade.id}" value="${escHtml(trade.notes || '')}">
          </div>
        </div>
        <div class="trade-right">
          ${pnlHtml}
          <div class="trade-time">${trade.tradeTime || (trade.isSample ? new Date(trade.timestamp).toLocaleTimeString('en-IN', {hour:'2-digit', minute:'2-digit'}) : '')}</div>
        </div>
      </div>
    `;
  }).join('');

  // Emotion handlers
  list.querySelectorAll('.emotion-select').forEach(sel => {
    sel.addEventListener('change', (e) => {
      e.stopPropagation();
      updateField(e.target.dataset.id, 'emotion', e.target.value);
    });
  });

  // Notes handlers (save on blur)
  list.querySelectorAll('.notes-input').forEach(input => {
    input.addEventListener('blur', (e) => {
      updateField(e.target.dataset.id, 'notes', e.target.value);
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') e.target.blur();
    });
  });
}

// ── SUMMARY VIEW ──

function renderSummary() {
  const now = new Date();

  // Week start (Monday)
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  weekStart.setHours(0, 0, 0, 0);

  // Month start
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  const weekTrades   = allTrades.filter(t => new Date(t.timestamp) >= weekStart);
  const monthTrades  = allTrades.filter(t => new Date(t.timestamp) >= monthStart);

  const weekCompleted  = weekTrades.filter(t => t.pnl !== null);
  const monthCompleted = monthTrades.filter(t => t.pnl !== null);
  const allCompleted   = allTrades.filter(t => t.pnl !== null);

  const weekPnL  = weekCompleted.reduce((s, t) => s + t.pnl, 0);
  const monthPnL = monthCompleted.reduce((s, t) => s + t.pnl, 0);

  const weekWinners  = weekCompleted.filter(t => t.pnl > 0).length;
  const monthWinners = monthCompleted.filter(t => t.pnl > 0).length;
  const allWinners   = allCompleted.filter(t => t.pnl > 0).length;

  const weekWR  = weekCompleted.length  ? Math.round(weekWinners  / weekCompleted.length  * 100) : 0;
  const monthWR = monthCompleted.length ? Math.round(monthWinners / monthCompleted.length * 100) : 0;
  const allWR   = allCompleted.length   ? Math.round(allWinners   / allCompleted.length   * 100) : 0;

  const weekBest = weekCompleted.length ? Math.max(...weekCompleted.map(t => t.pnl)) : 0;
  const monthWorst = monthCompleted.length ? Math.min(...monthCompleted.map(t => t.pnl)) : 0;

  // Best/worst day
  const dayMap = {};
  allCompleted.forEach(t => {
    const d = new Date(t.timestamp).toDateString();
    dayMap[d] = (dayMap[d] || 0) + t.pnl;
  });
  const dayVals = Object.values(dayMap);
  const bestDay  = dayVals.length ? Math.max(...dayVals) : 0;
  const worstDay = dayVals.length ? Math.min(...dayVals) : 0;

  // Update DOM
  setVal('week-pnl',    weekPnL,    true);
  setVal('month-pnl',   monthPnL,   true);
  setVal('all-best-day',  bestDay,  true);
  setVal('all-worst-day', worstDay, true);
  setVal('week-best',   weekBest,   true);
  setVal('month-worst', monthWorst, true);

  document.getElementById('week-trades').textContent  = weekTrades.length;
  document.getElementById('month-trades').textContent = monthTrades.length;
  document.getElementById('all-total-trades').textContent = allTrades.length;
  document.getElementById('week-winrate').textContent  = weekWR + '%';
  document.getElementById('month-winrate').textContent = monthWR + '%';
  document.getElementById('all-winrate').textContent   = allWR + '%';
}

function setVal(id, val, isPnL) {
  const el = document.getElementById(id);
  if (!el) return;
  if (isPnL) {
    el.textContent = formatPnL(val);
    el.className = 's-val ' + (val > 0 ? 'green' : val < 0 ? 'red' : 'white');
  } else {
    el.textContent = val;
  }
}

// ── FIELD UPDATE ──

function updateField(id, field, value) {
  const idx = allTrades.findIndex(t => t.id === id);
  if (idx === -1) return;
  allTrades[idx][field] = value;
  chrome.storage.local.set({ trades: allTrades });
}

// ── EXPORT TO CSV ──

function setupExportBtn() {
  document.getElementById('export-btn').addEventListener('click', exportCSV);
}

function exportCSV() {
  if (allTrades.length === 0) {
    alert('No trades to export yet.');
    return;
  }

  const headers = ['Date', 'Time', 'Symbol', 'Exchange', 'Action', 'Qty', 'Price', 'Value', 'Product', 'P&L', 'Platform', 'Emotion', 'Notes'];
  const rows = allTrades.map(t => [
    t.tradeDate || new Date(t.timestamp).toLocaleDateString('en-IN'),
    t.tradeTime || '',
    t.symbol || '',
    t.exchange || 'NSE',
    t.action || '',
    t.quantity || 0,
    t.price || 0,
    ((t.quantity || 0) * (t.price || 0)).toFixed(2),
    t.product || 'MIS',
    t.pnl !== null ? t.pnl : '',
    t.source || '',
    t.emotion || '',
    (t.notes || '').replace(/,/g, ';') // avoid CSV breaking on commas in notes
  ]);

  const csv = [headers, ...rows].map(r => r.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = `tradelog_${new Date().toISOString().slice(0,10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ── MARKET STATUS ──

function updateMarketStatus() {
  const now = new Date();
  const totalMinutes = now.getHours() * 60 + now.getMinutes();
  const day = now.getDay();
  const isWeekday = day >= 1 && day <= 5;
  const isDuringHours = totalMinutes >= (9*60+15) && totalMinutes <= (15*60+30);

  const statusEl = document.getElementById('market-status');
  if (isWeekday && isDuringHours) {
    statusEl.textContent = 'MARKET OPEN';
    statusEl.className = 'market-status market-open';
  } else {
    statusEl.textContent = 'MARKET CLOSED';
    statusEl.className = 'market-status market-closed';
  }
}

// ── SOURCE DOTS ──

function updateSourceDots() {
  ['zerodha', 'groww', 'upstox', 'angelone'].forEach(src => {
    const dot = document.getElementById('dot-' + src);
    if (dot) dot.classList.toggle('active', allTrades.some(t => t.source === src));
  });
}

// ── TABS ──

function setupTabs() {
  document.querySelector('.tabs').addEventListener('click', (e) => {
    const tab = e.target.closest('.tab');
    if (!tab) return;
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    currentFilter = tab.dataset.filter;

    const debriefView = document.getElementById('debrief-view');
    const summaryView = document.getElementById('summary-view');
    const tradeList = document.getElementById('trade-list');

    if (currentFilter === 'debrief') {
      debriefView.classList.add('active');
      summaryView.style.display = 'none';
      tradeList.style.display = 'none';
      renderDebrief();
    } else if (currentFilter === 'summary') {
      debriefView.classList.remove('active');
      summaryView.style.display = 'block';
      tradeList.style.display = 'none';
      renderSummary();
    } else {
      debriefView.classList.remove('active');
      summaryView.style.display = 'none';
      tradeList.style.display = 'block';
      renderTrades(currentFilter);
    }
  });
}

// ── DEBRIEF / WHY DID I LOSE ──

function renderDebrief() {
  const today = new Date().toDateString();
  const todayTrades = allTrades.filter(t => new Date(t.timestamp).toDateString() === today);
  const losingTrades = todayTrades.filter(t => t.pnl !== null && t.pnl < 0);
  const winningTrades = todayTrades.filter(t => t.pnl !== null && t.pnl > 0);
  const totalPnL = todayTrades.reduce((s, t) => s + (t.pnl || 0), 0);

  // streak
  updateStreak(todayTrades.length > 0);

  const container = document.getElementById('debrief-analysis');

  if (todayTrades.length === 0) {
    container.innerHTML = `
      <div class="debrief-card neutral">
        <div class="debrief-label">Analysis</div>
        <div class="debrief-value">No trades today yet.</div>
        <div class="debrief-insight neutral">Place trades and come back here after market close.</div>
      </div>`;
    return;
  }

  let html = '';

  // Overall result
  const resultClass = totalPnL >= 0 ? 'win' : 'loss';
  html += `<div class="debrief-card ${resultClass}">
    <div class="debrief-label">Today's Result</div>
    <div class="debrief-value">${totalPnL >= 0 ? '+' : ''}₹${totalPnL.toFixed(0)} across ${todayTrades.length} trades</div>
    <div class="debrief-insight ${totalPnL >= 0 ? 'positive' : ''}">
      ${totalPnL >= 0 ? '✅ Profitable day! ' + winningTrades.length + ' winners, ' + losingTrades.length + ' losers.' : '❌ Loss day. ' + losingTrades.length + ' losing trades out of ' + todayTrades.length + '.'}
    </div>
  </div>`;

  // Pattern analysis
  if (losingTrades.length > 0) {
    const biggestLoss = losingTrades.reduce((min, t) => t.pnl < min.pnl ? t : min, losingTrades[0]);
    html += `<div class="debrief-card loss">
      <div class="debrief-label">Biggest Loss</div>
      <div class="debrief-value">${biggestLoss.symbol} — ₹${Math.abs(biggestLoss.pnl).toFixed(0)} loss (${biggestLoss.type} ${biggestLoss.qty} qty @ ₹${biggestLoss.price})</div>
      <div class="debrief-insight">Was this your setup or did you force the trade?</div>
    </div>`;
  }

  // Overtrading check
  if (todayTrades.length > 5) {
    html += `<div class="debrief-card loss">
      <div class="debrief-label">⚠️ Overtrading Alert</div>
      <div class="debrief-value">${todayTrades.length} trades in one day</div>
      <div class="debrief-insight">More than 5 trades/day often leads to revenge trading. Review each trade.</div>
    </div>`;
  }

  // Win/loss ratio insight
  if (todayTrades.length >= 2) {
    const winRate = Math.round((winningTrades.length / todayTrades.length) * 100);
    html += `<div class="debrief-card ${winRate >= 50 ? 'win' : 'neutral'}">
      <div class="debrief-label">Win Rate Today</div>
      <div class="debrief-value">${winRate}% (${winningTrades.length} of ${todayTrades.length} trades)</div>
      <div class="debrief-insight ${winRate >= 50 ? 'positive' : 'neutral'}">${winRate >= 60 ? 'Strong execution today.' : winRate >= 40 ? 'Average day. Focus on setup quality.' : 'Review your entries — were you following your rules?'}</div>
    </div>`;
  }

  container.innerHTML = html;
}

function updateStreak(tradedToday) {
  try {
    const data = JSON.parse(localStorage.getItem('tl_streak') || '{"count":0,"lastDate":""}');
    const today = new Date().toDateString();
    if (data.lastDate === today) {
      // already counted
    } else if (tradedToday) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      data.count = data.lastDate === yesterday.toDateString() ? data.count + 1 : 1;
      data.lastDate = today;
      localStorage.setItem('tl_streak', JSON.stringify(data));
    }
    document.getElementById('streak-num').textContent = data.count;
    document.getElementById('streak-msg').textContent =
      data.count === 0 ? 'Trade today to start your streak' :
      data.count < 3 ? 'Keep going!' :
      data.count < 7 ? 'Great consistency!' :
      data.count < 30 ? '🔥 You\'re on fire!' : '🏆 Elite journaler!';
  } catch(e) {}
}

function setupChecklist() {
  try {
    const saved = JSON.parse(localStorage.getItem('tl_checklist') || '{}');
    const today = new Date().toDateString();
    const checks = saved.date === today ? saved.checks : {};
    for (let i = 1; i <= 5; i++) {
      const cb = document.getElementById('c' + i);
      const item = document.getElementById('ci' + i);
      if (!cb) continue;
      cb.checked = !!checks['c' + i];
      if (cb.checked) item.classList.add('checked');
      cb.addEventListener('change', () => {
        item.classList.toggle('checked', cb.checked);
        checks['c' + i] = cb.checked;
        try { localStorage.setItem('tl_checklist', JSON.stringify({ date: today, checks })); } catch(e) {}
      });
    }
  } catch(e) {}
}

// ── LOSS LIMIT SETTING ──

function setupLossLimit() {
  const input = document.getElementById('loss-limit-input');
  const saveBtn = document.getElementById('loss-limit-save');
  const status = document.getElementById('loss-limit-status');
  if (!input || !saveBtn) return;

  // Load saved limit
  chrome.storage.local.get(['lossLimit'], (result) => {
    if (result.lossLimit && result.lossLimit > 0) {
      input.value = result.lossLimit;
      status.textContent = `Active: Stop trading if loss hits ₹${result.lossLimit.toLocaleString('en-IN')} today`;
      status.style.color = '#FF5A5A';
    }
  });

  saveBtn.addEventListener('click', () => {
    const val = parseInt(input.value, 10);
    if (!val || val <= 0) {
      chrome.storage.local.remove('lossLimit', () => {
        status.textContent = 'Loss limit cleared.';
        status.style.color = '#5C6480';
      });
      return;
    }
    chrome.storage.local.set({ lossLimit: val, lossAlertDate: '' }, () => {
      status.textContent = `✅ Set — alert fires if you lose ₹${val.toLocaleString('en-IN')} today`;
      status.style.color = '#34C77B';
      setTimeout(() => {
        status.textContent = `Active: Stop trading if loss hits ₹${val.toLocaleString('en-IN')} today`;
        status.style.color = '#FF5A5A';
      }, 2500);
    });
  });

  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveBtn.click(); });
}

// ── CLEAR ──

function setupClearBtn() {
  document.getElementById('clear-btn').addEventListener('click', () => {
    if (confirm('Clear all trade history?')) {
      chrome.storage.local.set({ trades: [], stats: {} }, () => {
        allTrades = [];
        chrome.action.setBadgeText({ text: '' });
        updateStatsStrip({});
        renderChart();
        renderTrades(currentFilter);
      });
    }
  });
}

// ── UTILS ──

function formatPnL(val) {
  if (val === null || val === undefined) return '—';
  const abs = Math.abs(val).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  return (val >= 0 ? '+₹' : '-₹') + abs;
}

function formatPrice(price) {
  if (!price) return '0';
  return Number(price).toLocaleString('en-IN', { maximumFractionDigits: 2 });
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── LICENSE KEY ──────────────────────────────────────────────────────────────
// Key format: TL-<BASE64URL(plan|expiry_ts)>-<HMAC_8_chars>
// HMAC is verified client-side using the same secret embedded here.
// This is "good enough" security for a ~₹999 product — the secret is in the
// extension source, so a determined person could extract it, but that's true
// of any client-side approach. The main protection is that keys expire.

const LICENSE_SECRET = 'TL-PROD-ANKIT-2024-XJ9K7M'; // must match server env var LICENSE_SECRET

async function hmac8(payload) {
  const enc  = new TextEncoder();
  const key  = await crypto.subtle.importKey(
    'raw', enc.encode(LICENSE_SECRET), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sig  = await crypto.subtle.sign('HMAC', key, enc.encode(payload));
  const hex  = Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2,'0')).join('');
  return hex.slice(0, 8).toUpperCase();
}

async function validateLicenseKey(raw) {
  const key = raw.trim().toUpperCase();
  // Format: TL-<b64>-<8HEX>
  const m = key.match(/^TL-([A-Z0-9_=-]+)-([0-9A-F]{8})$/i);
  if (!m) return { valid: false, reason: 'Invalid format' };

  const [, b64, mac] = m;
  let payload;
  try {
    payload = atob(b64.replace(/-/g,'+').replace(/_/g,'/'));
  } catch {
    return { valid: false, reason: 'Corrupt key' };
  }

  const [plan, tsStr] = payload.split('|');
  const expiry = parseInt(tsStr, 10);
  if (!plan || !expiry || isNaN(expiry)) return { valid: false, reason: 'Corrupt key' };

  const expectedMac = await hmac8(payload);
  if (expectedMac !== mac.toUpperCase()) return { valid: false, reason: 'Invalid key' };

  if (Date.now() > expiry) {
    return { valid: false, reason: 'Key expired', expired: true, plan };
  }

  return { valid: true, plan, expiry };
}

function setupLicenseKey() {
  const input    = document.getElementById('license-input');
  const btn      = document.getElementById('license-activate-btn');
  const status   = document.getElementById('license-status');
  const proInfo  = document.getElementById('license-pro-info');

  if (!input || !btn) return;

  // Show current status on load
  chrome.storage.local.get(['isPro', 'licenseKey', 'licenseExpiry', 'licensePlan'], (r) => {
    if (r.isPro && r.licenseKey) {
      showProActive(r.licensePlan, r.licenseExpiry, proInfo, status, input, btn);
    }
  });

  btn.addEventListener('click', async () => {
    const raw = input.value.trim();
    if (!raw) { showStatus(status, 'Paste your license key above.', 'warn'); return; }

    btn.textContent = 'Checking…'; btn.disabled = true;
    const result = await validateLicenseKey(raw);
    btn.textContent = 'Activate'; btn.disabled = false;

    if (result.valid) {
      chrome.storage.local.set({
        isPro: true,
        licenseKey: raw.trim().toUpperCase(),
        licenseExpiry: result.expiry,
        licensePlan: result.plan,
      }, () => {
        showProActive(result.plan, result.expiry, proInfo, status, input, btn);
      });
    } else if (result.expired) {
      showStatus(status, `Key expired — please renew your ${result.plan} plan.`, 'error');
    } else {
      showStatus(status, result.reason || 'Invalid key. Check and try again.', 'error');
    }
  });
}

function showProActive(plan, expiry, proInfo, status, input, btn) {
  if (input) input.style.display = 'none';
  if (btn)   btn.style.display   = 'none';
  if (status) status.style.display = 'none';
  if (proInfo) {
    proInfo.style.display = 'flex';
    const planEl   = document.getElementById('license-plan-name');
    const expiryEl = document.getElementById('license-expiry-date');
    if (planEl)   planEl.textContent   = plan === 'lifetime' ? 'Pro Lifetime' : 'Pro Monthly';
    if (expiryEl) expiryEl.textContent = plan === 'lifetime'
      ? 'Never expires'
      : 'Expires ' + new Date(expiry).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
  }
}

function showStatus(el, msg, type) {
  if (!el) return;
  el.textContent = msg;
  el.style.color = type === 'error' ? 'var(--loss)' : type === 'warn' ? 'var(--text3)' : 'var(--profit)';
  el.style.display = 'block';
}
